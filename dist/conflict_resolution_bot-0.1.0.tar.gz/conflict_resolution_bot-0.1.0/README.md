

to run gemini, run:

```
poetry build
```

```
poetry run python src/conflict_resolution_bot/hello.py
```