# src/conflict_resolution_bot/app.py

from fastapi import FastAPI

app = FastAPI()
